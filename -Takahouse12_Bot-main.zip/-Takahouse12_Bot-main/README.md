2025 Bast earning 
